import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss']
})
export class DynamicFormComponent implements OnInit {

  config = [
    {
      type: 'input',
      label: 'Full name',
      name: 'name',
      placeholder: 'Enter your name',
    },
    {
      type: 'select',
      label: 'Favourite food',
      name: 'food',
      options: ['Pizza', 'Hot Dogs', 'Knakworstje', 'Coffee'],
      placeholder: 'Select an option',
    },
    {
      label: 'Submit',
      name: 'submit',
      type: 'submit',
    },
  ];
  form:FormGroup;
  field:any={
    type: 'input',
    label: 'Full name',
    name: 'name',
    placeholder: 'Enter your name',
  };
  constructor(private fb: FormBuilder) { 
  }

  ngOnInit(): void {
    this.form = this.createGroup();
  }
  createGroup(){
    const group = this.fb.group({});
    this.config.forEach(control=>{
      group.addControl(control.name, this.fb.control(control))
    })
    return group;
  }
  checkComponentType(type){
   this.field =  this.config.find(field=> field.type === type);
  }

}
