import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { FormsComponent } from './forms/forms.component';
import { DynamicFormComponent } from './dynamic-form/dynamic-form.component';


const routes: Routes = [
  {path:'',redirectTo: 'home',pathMatch:'full'},
  { path: 'home', loadChildren: () => import('./home/home.module').then(m => m.HomeModule) }, 
  { path: 'todos', loadChildren: () => import('./todos/todos.module').then(m => m.TodosModule) },
   { path: 'forms', component: FormsComponent}, 
  { path: 'dynamic', component: DynamicFormComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    initialNavigation: 'enabled'
})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
