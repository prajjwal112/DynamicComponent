import { DynamicFieldDirective } from './dynamic-field.directive';

describe('DynamicFieldDirective', () => {
  it('should create an instance', () => {
    const directive = new DynamicFieldDirective();
    expect(directive).toBeTruthy();
  });
});
