import { Directive, Input, OnInit, OnChanges, ComponentFactoryResolver, ViewContainerRef } from '@angular/core';
import { SubmitComponent } from './submit/submit.component';
import { SelectComponent } from './select/select.component';
import { InputComponent } from './input/input.component';

const components = {
  submit: SubmitComponent,
  select: SelectComponent,
  input: InputComponent
}
@Directive({
  selector: '[appDynamicField]'
})
export class DynamicFieldDirective implements OnInit, OnChanges {

  @Input() config:any;
  @Input() group:any;
  componentRef:any;
  constructor(private cfr: ComponentFactoryResolver, private vcr: ViewContainerRef ) { }

  ngOnInit(){
    this.vcr.clear();
    const componentFactory = this.cfr.resolveComponentFactory<any>(components[this.config.type]); //the object that knows how to build our component.
    this.componentRef = this.vcr.createComponent(componentFactory);
    /*While the createComponent function call of the viewContainerRef object is enough to instantiate our 
    component in the DOM, we create a variable to hold reference to our component in order to pass in 
    any values needed for its configuration.What’s neat is that this variable acts as a live reference
     to our component, any values changed will trigger the component’s detection system and bind values in its view.*/
    this.componentRef.instance.config = this.config;
    this.componentRef.instance.group = this.group;
  }

  ngOnChanges(){
    if(this.componentRef){
      //this.vcr.clear();
    const componentFactory = this.cfr.resolveComponentFactory<any>(components[this.config.type]); 
    this.componentRef = this.vcr.createComponent(componentFactory);
    this.componentRef.instance.config = this.config;
    this.componentRef.instance.group = this.group;
    }
  }
}
