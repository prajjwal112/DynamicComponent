import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.scss']
})
export class FormsComponent implements OnInit {
userForm:FormGroup;
dropdownOPtions=['india','america','britain','greenland','iceland'] ;
constructor(private fb: FormBuilder){
this.userForm = this.fb.group({
  subUserForm: this.fb.array([this.subUserForm])
})
}

get subUserForm():FormGroup{
  return this.fb.group({
    firstName:'',
    lastName:'',
    checkbox:this.fb.array([this.checkbox]),
    selectbox:['']
  })
}

get checkbox():FormGroup{
  return this.fb.group({
    male:true,
    female:false
  })
}
addUser(){
  (this.userForm.get('subUserForm')as FormArray).push(this.subUserForm);
}

  ngOnInit(): void {
  }

}
